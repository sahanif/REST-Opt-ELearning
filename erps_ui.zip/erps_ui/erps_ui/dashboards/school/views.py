from django.http import HttpResponse
import requests
import datetime
import json
import time
import threading

from django.shortcuts import render
# from .models import menu_tree as usps_menu

from erps_ui.dashboards.common import common as my_common
from erps_ui.dashboards.common import constant as my_constant

from django.conf import settings
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _


# Create your views here.
def check_moodle_process(schoolId, httpPort, httpsPort):

    print('check_moodle_process')
    moodle_url = 'http://' + my_constant.api_host + ':' + httpPort.split('/')[0]
    new_params = {}
    while True:
        time.sleep(1)
        try:
            requests.head(moodle_url)
            new_params["activatedAt"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.000000")
            while True:
                res = requests.put(my_constant.school_url + str(schoolId) + "/", json=new_params)
                if res.status_code < 300:
                    break
                time.sleep(1)
            break
        except:
            print('service down - id: ' + str(schoolId))


def index(request):

    params = request.GET.copy()

    header_data = []
    body_data = []

    header_data.append({"name": "ID"})
    header_data.append({"name": "Name"})
    header_data.append({"name": "Address"})
    header_data.append({"name": "City"})
    header_data.append({"name": "Province"})
    header_data.append({"name": "Postal Code"})
    header_data.append({"name": "Head Master"})
    header_data.append({"name": "Phone"})
    header_data.append({"name": "Mobile"})
    header_data.append({"name": "Email"})
    header_data.append({"name": "School Type"})
    header_data.append({"name": "Tenant"})
    header_data.append({"name": "Port"})
    header_data.append({"name": "Namespace"})
    header_data.append({"name": "Created Date"})
    header_data.append({"name": "Activated Date"})
    header_data.append({"name": "Action"})

    try:
        response = requests.get(my_constant.school_url)
        response = response.json()
        response = response['results']
    except Exception as e:
        print(str(e))
        response = []

    tenant_info = requests.get(my_constant.tenant_url)
    tenant_info = tenant_info.json()
    tenant_info = tenant_info['results']
    for school in response:
        school['tenantName'] = "-"
        for tenant in tenant_info:
            if school['tenantId'] == str(tenant['id']):
                school['tenantName'] = tenant['name']
                continue

    schoolType_info = requests.get(my_constant.schoolType_url)
    schoolType_info = schoolType_info.json()
    schoolType_info = schoolType_info['results']
    for school in response:
        school['schoolTypeName'] = "-"
        if school['activatedAt'] == '1970-01-01T00:00:00Z':
            school['activatedAt'] = '-'
        for schoolType in schoolType_info:
            if school['schoolTypeId'] == str(schoolType['id']):
                school['schoolTypeName'] = schoolType['name']
                continue

    userlevel = request.session.get('userlevel', None)
    usertenantId = request.session.get('usertenantId', None)
    id = 1
    for info in response:
        if userlevel > 1:
            if usertenantId != info['tenantId']:
                continue
        if 'tenantId' in params:
            if params['tenantId'] != info['tenantId']:
                continue
        body_data.append({"uid": info["id"], "id": id, "name": info["name"], "address": info["address"],
                          "city": info["city"], "province": info["province"], "postalCode": info["postalCode"],
                          "headMaster": info["headMaster"], "phone": info["phone"], "mobile": info["mobile"],
                          "email": info["email"], "schoolTypeId": info["schoolTypeId"], "tenantId": info["tenantId"],
                          "httpPort": info["httpPort"].split("/")[0], "httpsPort": info["httpsPort"].split("/")[0],
                          "createdAt": info["createdAt"].split("T")[0], "activatedAt": info["activatedAt"].split("T")[0],
                          "tenantName": info["tenantName"], "schoolTypeName": info["schoolTypeName"],
                          "namespace": info["namespace"]})
        id = id + 1

    return render(request, 'dashboards/school/index.html', {
        'headerdata': header_data,
        'bodydata': body_data,
        'userlevel': userlevel,
        'hostip': my_constant.api_host,
    })


def get_active_date(request):
    response = requests.get(my_constant.school_url)
    response = response.json()
    response = response['results']
    res = []
    for school in response:
        if school['activatedAt'] == '1970-01-01T00:00:00Z':
            school['activatedAt'] = '-'
        res.append({
            'id': school['id'],
            'name': school['name'],
            'activatedAt': school['activatedAt'],
            'createdAt': school['createdAt'],
        })
    return HttpResponse(json.dumps(res))


def delete_school(request):
    params = request.POST

    res = requests.delete(my_constant.school_url + params["id"] + "/")

    user_name = request.session.get("username", None)
    if res.status_code < 300:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Delete", "Success",
                                          "/school/" + params["id"], request.get_host())
        return HttpResponse("success")
    else:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Delete", "Fail", "/school/" + params["id"],
                                          request.get_host())
        return HttpResponse("fail")


def update_school(request):
    params = request.POST

    new_params = {}

    new_params["name"] = params["name"]
    new_params["address"] = params["address"]
    new_params["city"] = params["city"]
    new_params["province"] = params["province"]
    new_params["postalCode"] = params["postalCode"]
    new_params["headMaster"] = params["headMaster"]
    new_params["phone"] = params["phone"]
    new_params["mobile"] = params["mobile"]
    new_params["email"] = params["email"]
    new_params["schoolTypeId"] = params["schoolTypeId"]
    new_params["tenantId"] = params["tenantId"]

    res = requests.put(my_constant.school_url + str(params["id"]) + "/", json=new_params)

    user_name = request.session.get("username", None)
    if res.status_code < 300:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Update", "Success",
                                          "/school/" + params["id"], request.get_host())
        return HttpResponse("success")
    else:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Update", "Fail",
                                          "/school/" + params["id"], request.get_host())
        return HttpResponse("fail")


def insert_school(request):
    params = request.POST

    new_params = {}

    new_params["name"] = params["name"]
    new_params["address"] = params["address"]
    new_params["city"] = params["city"]
    new_params["province"] = params["province"]
    new_params["postalCode"] = params["postalCode"]
    new_params["headMaster"] = params["headMaster"]
    new_params["phone"] = params["phone"]
    new_params["mobile"] = params["mobile"]
    new_params["email"] = params["email"]
    new_params["schoolTypeId"] = params["schoolTypeId"]
    new_params["tenantId"] = params["tenantId"]
    new_params["createdAt"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.000000")
    new_params["activatedAt"] = datetime.datetime(1970, 1, 1).strftime("%Y-%m-%d %H:%M:%S.000000")

    new_params["namespace"] = ''
    new_params["httpPort"] = ''
    new_params["httpsPort"] = ''
    new_params["webUsername"] = ''
    new_params["webPassword"] = ''

    res = requests.post(my_constant.school_url, json=new_params)
    school = json.loads(res.content)

    t = threading.Thread(target=check_moodle_process, args=(school['id'], school['httpPort'], school['httpsPort']), kwargs={})
    t.setDaemon(True)
    t.start()

    user_name = request.session.get("username", None)
    if res.status_code < 300:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Insert", "Success",
                                          "/school", request.get_host())
        return HttpResponse("success")
    else:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Insert", "Fail",
                                          "/school", request.get_host())
        return HttpResponse("fail")


def edit_school_view(request):

    params = request.POST.copy()
    if 'schoolTypeId' in params:
        params['schoolTypeId'] = int(params['schoolTypeId'])
    if 'tenantId' in params:
        params['tenantId'] = int(params['tenantId'])

    tenant_info = requests.get(my_constant.tenant_url)
    tenant_info = tenant_info.json()
    tenant_info = tenant_info['results']

    schoolType_info = requests.get(my_constant.schoolType_url)
    schoolType_info = schoolType_info.json()
    schoolType_info = schoolType_info['results']

    return render(request, 'dashboards/school/editschool.html', {
        'userdata': params,
        'tenant_info': tenant_info,
        'schoolType_info': schoolType_info,
    })

def add_school_view(request):

    tenant_info = requests.get(my_constant.tenant_url)
    tenant_info = tenant_info.json()
    tenant_info = tenant_info['results']

    schoolType_info = requests.get(my_constant.schoolType_url)
    schoolType_info = schoolType_info.json()
    schoolType_info = schoolType_info['results']

    return render(request, 'dashboards/school/addschool.html', {
        'tenant_info': tenant_info,
        'schoolType_info': schoolType_info,
    })
