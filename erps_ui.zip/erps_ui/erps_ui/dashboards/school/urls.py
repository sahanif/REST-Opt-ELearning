__author__ = 'com'

from django.conf.urls import url
from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),

    url(r'^insert_school', views.insert_school, name='insert_school'),
    url(r'^delete_school', views.delete_school, name='delete_school'),
    url(r'^update_school', views.update_school, name='update_school'),
    url(r'^edit_school_view', views.edit_school_view, name='edit_school_view'),
    url(r'^add_school_view', views.add_school_view, name='add_school_view'),

    url(r'^get_active_date', views.get_active_date, name='get_active_date'),
]
