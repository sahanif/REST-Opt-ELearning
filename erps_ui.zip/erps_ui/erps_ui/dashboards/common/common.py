import requests
import json
import datetime


from erps_ui.dashboards.common import constant as my_constant


def trace_access_history(request, username, type, ip_addr):
    params = {}

    params["username"] = username
    params["type"] = type
    params["time"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.000000")
    params["ip_addr"] = ip_addr

    return requests.post(my_constant.accesshistory_url, json=params)


def trace_event_history(request, username, type, result, part, ip_addr):
    params = {}

    params["username"] = username
    params["type"] = type
    params["result"] = result
    params["part"] = part
    params["time"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.000000")
    params["ip_addr"] = ip_addr

    return requests.post(my_constant.eventhistory_url, json=params)


def send_request(type, url, data=None, pk=None):
    if type == "get":
        res = requests.get(url)
        if res.status_code != my_constant.HttpResponse_OK:
            res = []
        else:
            res = res.json()
        return res

    if type == "post":
        res = requests.post(url, data=json.dumps(data), headers=my_constant.request_header)
        return res

    if type == "put":
        res = requests.put(url + str(pk) + "/", data=json.dumps(data), headers=my_constant.request_header)
        return res

    if type == "delete":
        res = requests.delete(url + str(pk) + "/")
        return res


def make_absolute_location(base_url, location):
    """
    Convert a location header into an absolute URL.
    """
    absolute_pattern = re.compile(r'^[a-zA-Z]+://.*$')
    if absolute_pattern.match(location):
        return location

    parsed_url = urlparse(base_url)

    if location.startswith('//'):
        # scheme relative
        return parsed_url.scheme + ':' + location

    elif location.startswith('/'):
        # host relative
        return parsed_url.scheme + '://' + parsed_url.netloc + location

    else:
        # path relative
        return parsed_url.scheme + '://' + parsed_url.netloc + parsed_url.path.rsplit('/', 1)[0] + '/' + location

    return location


def get_headers(environ):
    """
    Retrieve the HTTP headers from a WSGI environment dictionary.  See
    https://docs.djangoproject.com/en/dev/ref/request-response/#django.http.HttpRequest.META
    """
    headers = {}
    for key, value in environ.items():
        # Sometimes, things don't like when you send the requesting host through.
        if key.startswith('HTTP_') and key != 'HTTP_HOST':
            headers[key[5:].replace('_', '-')] = value
        elif key in ('CONTENT_TYPE', 'CONTENT_LENGTH'):
            headers[key.replace('_', '-')] = value

    return headers




