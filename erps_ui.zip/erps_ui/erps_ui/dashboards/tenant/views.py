from django.http import HttpResponse
import requests
import datetime
import json

from django.shortcuts import render
# from .models import menu_tree as usps_menu

from erps_ui.dashboards.common import common as my_common
from erps_ui.dashboards.common import constant as my_constant

from django.conf import settings
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _


# Create your views here.

def index(request):
    header_data = []
    body_data = []

    header_data.append({"name": "ID"})
    header_data.append({"name": "Code"})
    header_data.append({"name": "Name"})
    header_data.append({"name": "Address"})
    header_data.append({"name": "City"})
    header_data.append({"name": "Province"})
    header_data.append({"name": "Postal Code"})
    header_data.append({"name": "Contact"})
    header_data.append({"name": "Phone"})
    header_data.append({"name": "Mobile"})
    header_data.append({"name": "Email"})
    header_data.append({"name": "Active Date"})
    header_data.append({"name": "Action"})

    try:
        response = requests.get(my_constant.tenant_url)
        response = response.json()
        response = response['results']
    except Exception as e:
        print(str(e))
        response = []

    id = 1
    for info in response:
        body_data.append({"uid": info["id"], "id": id, "code": info["code"], "name": info["name"], "address": info["address"],
                          "city": info["city"], "province": info["province"], "postalCode": info["postalCode"],
                          "contactPerson": info["contactPerson"], "phone": info["phone"], "mobile": info["mobile"],
                          "email": info["email"], "activeDate": info["activeDate"].split(" ")[0]})
        id = id + 1

    return render(request, 'dashboards/tenant/index.html', {'headerdata': header_data, 'bodydata': body_data})



def delete_tenant(request):
    params = request.POST

    res = requests.delete(my_constant.tenant_url + params["id"] + "/")

    user_name = request.session.get("username", None)
    if res.status_code < 300:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Delete", "Success",
                                          "/tenant/" + params["id"], request.get_host())
        return HttpResponse("success")
    else:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Delete", "Fail", "/tenant/" + params["id"],
                                          request.get_host())
        return HttpResponse("fail")


def update_tenant(request):
    params = request.POST

    new_params = {}

    new_params["code"] = params["code"]
    new_params["name"] = params["name"]
    new_params["address"] = params["address"]
    new_params["city"] = params["city"]
    new_params["province"] = params["province"]
    new_params["postalCode"] = params["postalCode"]
    new_params["contactPerson"] = params["contactPerson"]
    new_params["phone"] = params["phone"]
    new_params["mobile"] = params["mobile"]
    new_params["email"] = params["email"]

    res = requests.put(my_constant.tenant_url + str(params["id"]) + "/", json=new_params)

    user_name = request.session.get("username", None)
    if res.status_code < 300:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Update", "Success",
                                          "/tenant/" + params["id"], request.get_host())
        return HttpResponse("success")
    else:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Update", "Fail",
                                          "/tenant/" + params["id"], request.get_host())
        return HttpResponse("fail")

def insert_tenant(request):
    params = request.POST

    new_params = {}

    new_params["code"] = params["code"]
    new_params["name"] = params["name"]
    new_params["address"] = params["address"]
    new_params["city"] = params["city"]
    new_params["province"] = params["province"]
    new_params["postalCode"] = params["postalCode"]
    new_params["contactPerson"] = params["contactPerson"]
    new_params["phone"] = params["phone"]
    new_params["mobile"] = params["mobile"]
    new_params["email"] = params["email"]
    new_params["activeDate"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.000000")

    res = requests.post(my_constant.tenant_url, json=new_params)

    user_name = request.session.get("username", None)
    if res.status_code < 300:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Insert", "Success",
                                          "/tenant", request.get_host())
        return HttpResponse("success")
    else:
        if user_name is not None:
            my_common.trace_event_history(request, user_name, "Insert", "Fail",
                                          "/tenant", request.get_host())
        return HttpResponse("fail")


def edit_tenant_view(request):
    params = request.POST
    return render(request, 'dashboards/tenant/edittenant.html', {'userdata': params})

def add_tenant_view(request):
    return render(request, 'dashboards/tenant/addtenant.html')
