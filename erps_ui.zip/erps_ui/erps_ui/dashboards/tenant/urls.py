__author__ = 'com'

from django.conf.urls import url
from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),

    url(r'^insert_tenant', views.insert_tenant, name='insert_tenant'),
    url(r'^delete_tenant', views.delete_tenant, name='delete_tenant'),
    url(r'^update_tenant', views.update_tenant, name='update_tenant'),
    url(r'^edit_tenant_view', views.edit_tenant_view, name='edit_tenant_view'),
    url(r'^add_tenant_view', views.add_tenant_view, name='add_tenant_view'),
]
