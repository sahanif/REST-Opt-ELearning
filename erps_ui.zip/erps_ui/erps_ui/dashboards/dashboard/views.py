from django.http import HttpResponse
import requests
import json

from django.core import serializers

from django.shortcuts import render
# from .models import menu_tree as usps_menu

from erps_ui.dashboards.common import common as my_common
from erps_ui.dashboards.common import constant as my_constant

from django.conf import settings
from django.urls import reverse
from django.utils.translation import ugettext_lazy as _


# Create your views here.

def welcome(request):
    return render(request, 'dashboards/dashboard/welcome.html')


def login(request):
    return render(request, 'dashboards/dashboard/login.html')


def register(request):
    return render(request, 'dashboards/dashboard/register.html')


def index(request):
    user_name = request.session.get("username", None)
    user_level = request.session.get("userlevel", None)

    if user_name is None:
        return render(request, "dashboards/dashboard/error.html")

    menu_data = requests.get(my_constant.menu_url)
    menu_data = menu_data.json()
    menu_data = menu_data['results']
    # menudata = usps_menu.objects.all()
    # menu_data = []
    # for menu in menudata:
    #     menu_data.append({"id": menu.id, "parent_id": menu.parent_id, "has_child": menu.has_child, "name": menu.name,
    #                       "icon": menu.icon, "url": menu.url, })

    new_menu_data = []
    for menu in menu_data:
        if menu["level"] >= user_level:
            new_menu_data.append({"id": menu["id"], "parent_id": menu["parent_id"], "has_child": menu["has_child"],
                                  "name": menu["name"], "icon": menu["icon"], "url": menu["url"]})

    return render(request, 'dashboards/dashboard/index.html', {
        'menudata': new_menu_data,
        'username': user_name,
        'userlevel': request.session.get('userlevel', None),
    })


def dashboardView(request):

    tenant_info = requests.get(my_constant.tenant_url)
    tenant_info = tenant_info.json()
    tenant_info = tenant_info['results']

    schoolType_info = requests.get(my_constant.schoolType_url)
    schoolType_info = schoolType_info.json()
    schoolType_info = schoolType_info['results']

    privilege_info = requests.get(my_constant.privilege_url)
    privilege_info = privilege_info.json()
    privilege_info = privilege_info['results']

    school_info = requests.get(my_constant.school_url)
    school_info = school_info.json()
    school_info = school_info['results']

    user_info = requests.get(my_constant.users_url)
    user_info = user_info.json()
    user_info = user_info['results']

    # type - school histogram
    type_school_histogram = []
    for schoolType in schoolType_info:
        count = 0
        for school in school_info:
            if school['schoolTypeId'] == str(schoolType['id']):
                count = count + 1
        if count > 0:
            type_school_histogram.append({
                'name': schoolType['name'],
                'count': count,
            })

    # tenant - school histogram
    tenant_school_histogram = []
    for tenant in tenant_info:
        count = 0
        for school in school_info:
            if school['tenantId'] == str(tenant['id']):
                count = count + 1
        if count > 0:
            tenant_school_histogram.append({
                'name': tenant['name'],
                'count': count,
            })

    # type - user histogram
    type_user_histogram = []
    for privilege in privilege_info:
        count = 0
        for user in user_info:
            if user['is_superuser'] == privilege['id']:
                count = count + 1
        if count > 0:
            type_user_histogram.append({
                'name': privilege['name'],
                'count': count,
            })

    # tenant - user histogram
    tenant_user_histogram = []
    for tenant in tenant_info:
        count = 0
        for user in user_info:
            if user['tenantId'] == str(tenant['id']):
                count = count + 1
        if count > 0:
            tenant_user_histogram.append({
                'name': tenant['name'],
                'count': count,
            })

    return render(request, 'dashboards/dashboard/dashboard.html', {
        'userlevel': request.session.get('userlevel', None),
        'type_school_histogram': json.dumps(type_school_histogram),
        'tenant_school_histogram': json.dumps(tenant_school_histogram),
        'type_user_histogram': json.dumps(type_user_histogram),
        'tenant_user_histogram': json.dumps(tenant_user_histogram),
    })


