from django.apps import AppConfig


class RbasisConfig(AppConfig):
    name = 'rbasis'
