sudo kubectl delete -f yaml/ -n $1
sudo kubectl delete ns $1
