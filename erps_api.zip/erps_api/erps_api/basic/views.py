import json
from django.http import HttpResponse
from rest_framework.response import Response
from rbasis.views import *
from .models import *
from .serializers import *

from django.conf import settings

import uuid
import os
import subprocess

# Create your views here.
class menu(ShAPIView):
    queryset = menu_tree.objects.all()
    serializer_class = menuTreeSerializer
    pass


class privilegeView(ShAPIView):
    queryset = privilege.objects.all()
    serializer_class = privilegeSerializer
    pass


class userView(ShAPIView):
    queryset = user.objects.all()
    serializer_class = userSerializer

    def list(self, request, *args, **kwargs):
        if len(request.query_params) == 0:
            return super().list(request, args, kwargs)

        params = request.query_params

        if "username" in request.query_params:
            self.queryset = user.objects.filter(username=params["username"])

        if ("email" in request.query_params) and ("password" in request.query_params):
            self.queryset = user.objects.filter(email=params["email"], password=params["password"])

        return super().list(request, args, kwargs)

    def update(self, request, *args, **kwargs):
        try:
            kwargs['partial'] = True
            return super().update(request, args, **kwargs)
        except Exception as e:
            print(e)
            return self.log(e)


class tenantView(ShAPIView):
    queryset = tenant.objects.all()
    serializer_class = tenantSerializer
    pass


class accesshistoryView(ShAPIView):
    queryset = access_history.objects.all()
    serializer_class = accesshistorySerializer

    def list(self, request, *args, **kwargs):
        if len(request.query_params) == 0:
            return super().list(request, args, kwargs)

        params = request.query_params

        if "username" in request.query_params:
            self.queryset = access_history.objects.filter(username=params["username"])

        return super().list(request, args, kwargs)


class eventhistoryView(ShAPIView):
    queryset = event_history.objects.all()
    serializer_class = eventhistorySerializer

    def list(self, request, *args, **kwargs):
        if len(request.query_params) == 0:
            return super().list(request, args, kwargs)

        params = request.query_params

        if "username" in request.query_params:
            self.queryset = event_history.objects.filter(username=params["username"])

        return super().list(request, args, kwargs)


class schoolView(ShAPIView):
    queryset = school.objects.all()
    serializer_class = schoolSerializer

    def list(self, request, *args, **kwargs):
        print("school list")
        res = super().list(request, args, kwargs)
        return res

    def update(self, request, *args, **kwargs):
        print("school update")
        res = super().update(request, args, **kwargs)
        return res

    def retrieve(self, request, *args, **kwargs):
        print("school retrieve")
        res = super().retrieve(request, args, kwargs)
        return res

    def destroy(self, request, *args, **kwargs):
        print("school destroy")
        res = super().destroy(request, args, kwargs)
        return res

    def partial_update(self, request, *args, **kwargs):
        print("school partial_update")
        res = super().partial_update(request, args, kwargs)
        return res

    def create(self, request, *args, **kwargs):
        print("school create")
        if not request.POST._mutable:
            request.POST._mutable = True
        request._data['namespace'] = 'namespace-' + str(uuid.uuid4())
        cmd = "cd " + settings.BASE_DIR + "/script/ && sudo ./create.sh " + request._data['namespace']
        res = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE).stdout.read().decode('utf-8')
        res = json.loads(res)
        request._data['httpPort'] = res['ports'].split(',')[0].split(':')[1]
        request._data['httpsPort'] = res['ports'].split(',')[1].split(':')[1]
        request._data['webUsername'] = 'user'
        request._data['webPassword'] = res['password']
        # request._data['httpPort'] = '233'
        # request._data['httpsPort'] = '333'
        # request._data['webUsername'] = 'user'
        # request._data['webPassword'] = 'password'
        res = super().create(request, args, kwargs)
        return res

    def perform_destroy(self, instance):
        print("school perform_destroy")
        cmd = "cd " + settings.BASE_DIR + "/script/ && sudo ./remove.sh " + instance.namespace + " &"
        os.system(cmd)
        res = super().perform_destroy(instance)
        return res


class schoolTypeView(ShAPIView):
    queryset = schoolType.objects.all()
    serializer_class = schoolTypeSerializer
    pass


