from django.db import models


# Create your models here.
class menu_tree(models.Model):
    parent_id = models.IntegerField(default=0)
    has_child = models.IntegerField(default=0)
    name = models.CharField(max_length=255)
    icon = models.CharField(max_length=255)
    url = models.CharField(max_length=255)
    level = models.IntegerField(default=0)


class privilege(models.Model):
    name = models.CharField(max_length=255)


class access_history(models.Model):
    username = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    time = models.DateTimeField()
    ip_addr = models.CharField(max_length=255)


class event_history(models.Model):
    username = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    result = models.CharField(max_length=255)
    part = models.CharField(max_length=255)
    time = models.DateTimeField(max_length=255)
    ip_addr = models.CharField(max_length=255)


class tenant(models.Model):
    code = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    address = models.CharField(max_length=255)
    city = models.CharField(max_length=255)
    province = models.CharField(max_length=255)
    postalCode = models.CharField(max_length=255)
    contactPerson = models.CharField(max_length=255)
    phone = models.CharField(max_length=255)
    mobile = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    activeDate = models.CharField(max_length=255, blank=True)


class user(models.Model):
    username = models.CharField(max_length=255)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    mobile = models.CharField(max_length=255)
    tenantId = models.CharField(max_length=255)
    is_superuser = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()


class school(models.Model):
    name = models.CharField(max_length=255, blank=True)
    address = models.CharField(max_length=255, blank=True)
    city = models.CharField(max_length=255, blank=True)
    province = models.CharField(max_length=255, blank=True)
    postalCode = models.CharField(max_length=255, blank=True)
    headMaster = models.CharField(max_length=255, blank=True)
    phone = models.CharField(max_length=255, blank=True)
    mobile = models.CharField(max_length=255, blank=True)
    email = models.CharField(max_length=255, blank=True)
    schoolTypeId = models.CharField(max_length=255, blank=True)
    tenantId = models.CharField(max_length=255, blank=True)
    namespace = models.CharField(max_length=255, blank=True)
    httpPort = models.CharField(max_length=255, blank=True)
    httpsPort = models.CharField(max_length=255, blank=True)
    webUsername = models.CharField(max_length=255, blank=True)
    webPassword = models.CharField(max_length=255, blank=True)
    createdAt = models.DateTimeField(blank=True)
    activatedAt = models.DateTimeField(blank=True)


class schoolType(models.Model):
    name = models.CharField(max_length=255)
