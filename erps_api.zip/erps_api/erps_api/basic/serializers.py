__author__ = 'com'
# from rest_framework import serializers
from .models import *
from rbasis.serializers import *

class menuTreeSerializer(ShAPISerializer):
    class Meta:
        model = menu_tree
        fields = ('id', 'parent_id', 'has_child', 'name', 'icon', 'url', 'level')


class privilegeSerializer(ShAPISerializer):
    class Meta:
        model = privilege
        fields = ('id', 'name')


class userSerializer(ShAPISerializer):
    class Meta:
        model = user
        fields = ('id', 'username', 'first_name', 'last_name', 'password',
                  'email', 'mobile', 'tenantId',  'is_superuser', 'is_active', 'date_joined')


class tenantSerializer(ShAPISerializer):
    class Meta:
        model = tenant
        fields = ('id', 'code', 'name', 'address', 'city',
                  'province', 'postalCode', 'contactPerson',
                  'phone', 'mobile', 'email', 'activeDate')


class accesshistorySerializer(ShAPISerializer):
    class Meta:
        model = access_history
        fields = ('id', 'username', 'type', 'time', 'ip_addr')


class eventhistorySerializer(ShAPISerializer):
    class Meta:
        model = event_history
        fields = ('id', 'username', 'type', 'result', 'part', 'time', 'ip_addr')


class schoolSerializer(ShAPISerializer):
    class Meta:
        model = school
        fields = ('id', 'name', 'address', 'city',
                  'province', 'postalCode', 'headMaster',
                  'phone', 'mobile', 'email', 'schoolTypeId',
                  'tenantId', 'namespace', 'httpPort', 'httpsPort',
                  'webUsername', 'webPassword', 'createdAt', 'activatedAt')


class schoolTypeSerializer(ShAPISerializer):
    class Meta:
        model = schoolType
        fields = ('id', 'name')



