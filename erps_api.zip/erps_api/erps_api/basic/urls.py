from rbasis.urlrouter import router
from . import views

def RegPath():
    router.register(r'menu',            views.menu,                 "menu",             "")
    router.register(r'user',            views.userView,             "user",             "")
    router.register(r'tenant',          views.tenantView,           "tenant",           "")
    router.register(r'privilege',       views.privilegeView,        "privilege",        "")
    router.register(r'accesshistory',   views.accesshistoryView,    "accesshistory",    "")
    router.register(r'eventhistory',    views.eventhistoryView,     "eventhistory",     "")
    router.register(r'school',          views.schoolView,           "school",           "")
    router.register(r'schoolType',      views.schoolTypeView,       "schoolType",       "")
